ECLAT BOOKING MODULE ONLY

Contains the booking Java controller/model/service/repository source, booking JSP pages, the scoped booking CSS, booking hero images, and booking PDF receipt test.

To integrate: copy the src folder into the root of the existing Eclat project, preserving folder paths.

This is NOT a standalone runnable application. It depends on the main project shared classes, user/customer, vendor, security, configuration, and build dependencies. Do not replace your project pom.xml or other members modules with this archive.
